package singletonpatternexample;


public class Logger {
private static Logger instance;
private Logger() {
    }
// Public method to provide access to the instance
 public static Logger getInstance() {
     if (instance == null) {
         // If instance is null,create a new instance
         instance = new Logger();
     }
     // Return the singleton instance
     return instance;
 }

 public void log(String message) {
     System.out.println("Log message: " + message);
 }
}
