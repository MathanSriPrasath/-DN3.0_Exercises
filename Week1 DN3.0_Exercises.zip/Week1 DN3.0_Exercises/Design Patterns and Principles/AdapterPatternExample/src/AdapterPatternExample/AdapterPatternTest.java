package AdapterPatternExample;

//AdapterPatternTest.java
public class AdapterPatternTest {

 public static void main(String[] args) {
     PaymentProcessor gatewayOneAdapter = new PaymentGatewayOneAdapter();
     PaymentProcessor gatewayTwoAdapter = new PaymentGatewayTwoAdapter();

     // Using Payment Gateway One through its adapter
     gatewayOneAdapter.processPayment(100.0);

     // Using Payment Gateway Two through its adapter
     gatewayTwoAdapter.processPayment(150.0);
 }
}

