package AdapterPatternExample;

//PaymentGatewayOneAdapter.java
public class PaymentGatewayOneAdapter implements PaymentProcessor {

 private PaymentGatewayOne gatewayOne;

 public PaymentGatewayOneAdapter() {
     this.gatewayOne = new PaymentGatewayOne();
 }

 @Override
 public void processPayment(double amount) {
     gatewayOne.doPayment(amount);
 }
}

//PaymentGatewayTwoAdapter.java
 class PaymentGatewayTwoAdapter implements PaymentProcessor {

 private PaymentGatewayTwo gatewayTwo;

 public PaymentGatewayTwoAdapter() {
     this.gatewayTwo = new PaymentGatewayTwo();
 }

 @Override
 public void processPayment(double amount) {
     gatewayTwo.performPayment(amount);
 }
}
