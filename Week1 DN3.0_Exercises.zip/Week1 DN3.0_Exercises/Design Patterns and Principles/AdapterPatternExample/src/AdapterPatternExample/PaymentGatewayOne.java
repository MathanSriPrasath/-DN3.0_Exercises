package AdapterPatternExample;

//PaymentGatewayOne.java
public class PaymentGatewayOne {
 public void doPayment(double amount) {
     System.out.println("Processing payment of $" + amount + " using Payment Gateway One.");
 }
}

//PaymentGatewayTwo.java
 class PaymentGatewayTwo {
 public void performPayment(double amount) {
     System.out.println("Performing payment of $" + amount + " via Payment Gateway Two.");
 }
}
