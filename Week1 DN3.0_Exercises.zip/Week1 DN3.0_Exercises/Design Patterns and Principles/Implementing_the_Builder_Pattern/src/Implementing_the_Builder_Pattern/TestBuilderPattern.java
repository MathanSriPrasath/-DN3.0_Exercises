package Implementing_the_Builder_Pattern;

//TestBuilderPattern.java

public class TestBuilderPattern {
 public static void main(String[] args) {
     // Create a Computer using the Builder pattern
     Computer computer1 = new Computer.Builder()
                             .cpu("Intel i7")
                             .ram(16)
                             .storage(512)
                             .build();

     // Another example with different configuration
     Computer computer2 = new Computer.Builder()
                             .cpu("AMD Ryzen 5")
                             .ram(8)
                             .storage(256)
                             .build();

     // Print out details of the created computers
     System.out.println("Computer 1:");
     System.out.println("CPU: " + computer1.getCpu());
     System.out.println("RAM: " + computer1.getRam() + "GB");
     System.out.println("Storage: " + computer1.getStorage() + "GB");

     System.out.println("\nComputer 2:");
     System.out.println("CPU: " + computer2.getCpu());
     System.out.println("RAM: " + computer2.getRam() + "GB");
     System.out.println("Storage: " + computer2.getStorage() + "GB");
 }
}
