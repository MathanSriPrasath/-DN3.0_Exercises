package Implementing_the_Builder_Pattern;

//Computer.java

public class Computer {
 private String cpu;
 private int ram; // in GB
 private int storage; // in GB
 // Other attributes as needed

 // Private constructor to be used by the Builder
 private Computer(Builder builder) {
     this.cpu = builder.cpu;
     this.ram = builder.ram;
     this.storage = builder.storage;
     // Initialize other attributes
 }

 // Getter methods for attributes
 public String getCpu() {
     return cpu;
 }

 public int getRam() {
     return ram;
 }

 public int getStorage() {
     return storage;
 }

 // Builder class
 public static class Builder {
     private String cpu;
     private int ram;
     private int storage;

     public Builder() {
         // Set default values if needed
     }

     public Builder cpu(String cpu) {
         this.cpu = cpu;
         return this;
     }

     public Builder ram(int ram) {
         this.ram = ram;
         return this;
     }

     public Builder storage(int storage) {
         this.storage = storage;
         return this;
     }

     // Build method to create Computer instance
     public Computer build() {
         return new Computer(this);
     }
 }
}
