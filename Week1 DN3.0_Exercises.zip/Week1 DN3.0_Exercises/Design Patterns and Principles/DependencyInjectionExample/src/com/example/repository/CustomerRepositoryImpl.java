package com.example.repository;



public class CustomerRepositoryImpl implements CustomerRepository {

 @Override
 public String findCustomerById(int id) {
     // For demonstration, return a mock customer.
     return "Customer " + id;
 }
}

