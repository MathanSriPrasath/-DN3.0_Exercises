package ImplementingtheMVCPattern;

//MVCPatternExample.java
public class MVCPatternExample {
 public static void main(String[] args) {
     // Create a Student
     Student student = new Student("John Doe", "123", "A");

     // Create a View
     StudentView view = new StudentView();

     // Create a Controller
     StudentController controller = new StudentController(student, view);

     // Display initial details
     controller.updateView();

     // Update Student details
     controller.setStudentName("Jane Doe");
     controller.setStudentGrade("A+");

     // Display updated details
     controller.updateView();
 }
}
